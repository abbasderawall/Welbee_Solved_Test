﻿namespace WriteUnitTest.Entities
{
    public class Lesson
    {
        public int LessonId;
        public double Grade;
        public bool IsPassed;
    }
}