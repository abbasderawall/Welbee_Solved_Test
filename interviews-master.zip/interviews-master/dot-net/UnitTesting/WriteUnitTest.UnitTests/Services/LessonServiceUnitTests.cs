﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WriteUnitTest.Services;

namespace WriteUnitTest.UnitTests.Services
{
    [TestClass]
    public class LessonServiceUnitTests
    {
        [TestMethod]
        public void UpdateLessonGrade_Test()
        {
            var lessonService = new LessonService();

            Assert.IsTrue(lessonService.UpdateLessonGrade(12, 64));
        }
        // if methods does not return anything it is either informative or imperative and it is not easy to test them in given environment therefore I re-factor the code and have return type to ensure that function run correctly.










    }
}