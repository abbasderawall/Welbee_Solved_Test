# .NET Coding and Thinking Challenges

Microsoft .NET based at home tests for engineering interviews.

Steps:

- open the project
- Modify the code as described in the README.md or Instructions.txt files inside the different folders.
- Send a link or zipfile of your edited project when you consider the assignment complete.