﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PatientDeIndentification.Models
{
    public class Patient
    {
       
        public int Id { get; set; }
        public DateTime birthDate { get; set; }
        public int zipCode { get; set; }
        public DateTime admissionDate { get; set; }
        public DateTime dischargeDate { get; set; }
        public string notes { get; set; }
    }
}
