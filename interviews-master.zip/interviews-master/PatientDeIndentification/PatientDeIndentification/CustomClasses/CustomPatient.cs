﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PatientDeIndentification.CustomClasses
{
    [Keyless]
    public partial class CustomPatient
    {
       
        public int age { get; set; }
        public int zipCode { get; set; }
        public int admissionYear { get; set; }
        public int dischargeYear { get; set; }
        public string notes { get; set; }
    }
}
