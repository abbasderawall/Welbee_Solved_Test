﻿using PatientDeIndentification.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PatientDeIndentification.DbContexts;

using PatientDeIndentification.CustomClasses;

namespace PatientDeIndentification.Repository
{
   public interface IPatientRepository
    {
        //IEnumerable<CustomPatient> GetPatients();

        CustomPatient PatientGetById(int Id);

        //CustomPatient GetCustomPatient(int Id);
        void AddPatient(Patient patient);
        void Save();


    }
}
