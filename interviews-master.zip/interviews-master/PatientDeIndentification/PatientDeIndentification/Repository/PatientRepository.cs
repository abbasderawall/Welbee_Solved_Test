﻿using PatientDeIndentification.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PatientDeIndentification.DbContexts;
using PatientDeIndentification.CustomClasses;
using System.Text.RegularExpressions;

namespace PatientDeIndentification.Repository
{
    public class PatientRepository : IPatientRepository
    {
        private readonly PatientDbContext patientDbContext;

        public PatientRepository(PatientDbContext dbContext)
        {
            patientDbContext = dbContext;
        }


        public void AddPatient(Patient patient)
        {
            patientDbContext.Add(patient);
            Save();
        }

      
        public CustomPatient PatientGetById(int id)
        {
            using (patientDbContext)
            {

                var patientData = from data in patientDbContext.patients
                                  where data.Id == id//patientDbContext.patients.Find(productId)
                                  select new CustomPatient
                                  {
                                      age = FindAge(data.birthDate),
                                      zipCode = data.zipCode,
                                      admissionYear = data.admissionDate.Year,
                                      dischargeYear = data.dischargeDate.Year,
                                      notes = EncodeSSN(data.notes),

                                  };
                var result = patientData.FirstOrDefault();
                return result;
                
            }


            
        }

        public void Save()
        {
            patientDbContext.SaveChanges();
        }

        private static int FindAge(DateTime dateOfBirth)
        {
            int age = 0;

            age = (DateTime.Now.Year - dateOfBirth.Year);
            if (DateTime.Now.DayOfYear < dateOfBirth.DayOfYear)
                age = (age - 1);

            return age;
        }

        public static string EncodeSSN(string ssn)
        {

            MatchCollection collection = Regex.Matches(ssn, @"\d{3}-\d{2}-\d{4}");


            foreach (Match SSN in collection)
            {
                ssn = ssn.Replace(SSN.Value, "XXX-XX-XXXX");
            }

            return ssn;
          
        }
    }
}
