﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PatientDeIndentification.Models;
using PatientDeIndentification.CustomClasses;

namespace PatientDeIndentification.DbContexts
{
    public class PatientDbContext: DbContext
    {

        public PatientDbContext(DbContextOptions<PatientDbContext> options) : base(options)
        {
           
        }
        public DbSet<Patient> patients { get; set; }
        public DbSet<CustomPatient> CutomPatients { get; set; }

    }

}
